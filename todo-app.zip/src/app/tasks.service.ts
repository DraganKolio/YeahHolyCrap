import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Task } from '../app/models/task.model';

@Injectable({
  providedIn: 'root'
})
export class TasksService {

  private apiURL = 'http://localhost:3000/api/tasks';

  constructor(private http: HttpClient) { }

  getTasks(): Observable<Task[]> {
    return this.http.get<Task[]>(this.apiURL);
  }

  getTaskById(taskId: string): Observable<Task> {
    const url = `${this.apiURL}/${taskId}`;
    return this.http.get<Task>(url);
  }

  createTask(newTask: Task): Observable<Task> {
    return this.http.post<Task>(this.apiURL, newTask);
  }

  updateTask(taskId: string, updatedTask: Task): Observable<Task> {
    const url = `${this.apiURL}/${taskId}`;
    return this.http.put<Task>(url, updatedTask);
  }

  deleteTask(taskId: string): Observable<void> {
    const url = `${this.apiURL}/${taskId}`;
    return this.http.delete<void>(url);
  }
}
