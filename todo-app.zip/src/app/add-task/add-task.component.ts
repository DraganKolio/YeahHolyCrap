import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TasksService } from '../tasks.service';

@Component({
  selector: 'app-add-task',
  templateUrl: './add-task.component.html',
  styleUrls: ['./add-task.component.css']
})
export class AddTaskComponent implements OnInit {
  taskForm!: FormGroup;

  constructor(private formBuilder: FormBuilder, private tasksService: TasksService) { }

  ngOnInit(): void {
    this.taskForm = this.formBuilder.group({
      name: ['', Validators.required],
      status: ['Not Finished', Validators.required]
    })
  }

  onSubmit() {
    if (this.taskForm.invalid) {
      return;
    }

    const newTaskData = this.taskForm.value;

    this.tasksService.createTask(newTaskData).subscribe(
      (createdTask) => {
        console.log('New task was added: ', createdTask);
      },
      (error) => {
        console.error('Error adding the task: ', error);
      }
    )
  }
}
