import { Component, OnInit } from '@angular/core';
import { Task } from '../../app/models/task.model';
import { TasksService } from '../tasks.service';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css']
})
export class TaskListComponent implements OnInit {

  tasks!: Task[];
  task!: Task;

  constructor(private tasksService: TasksService) { }

  ngOnInit(): void {
    this.loadTasks();
  }

  loadTasks() {
    this.tasksService.getTasks().subscribe(
      (tasks) => {
        this.tasks = tasks;
        const tasksJSON = JSON.stringify(this.tasks);
        console.log(tasksJSON);
      },
      (error) => {
        console.error('Error fetching tasks: ', error);
      }
    )
  }

}
