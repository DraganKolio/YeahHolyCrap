export interface Task {
  _id: string,
  name: string,
  status: string,
  encodedID?: string;
}