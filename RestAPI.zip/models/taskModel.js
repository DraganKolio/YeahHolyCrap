// dependencies
const mongoose = require('mongoose');

// Define the Task schema
const taskSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  status: {
    type: String,
    enum: ['Finished', 'Not Finished'],
    default: 'Not Finished',
  }
});

// Create the Task Model
const Task = mongoose.model('Task', taskSchema);

module.exports = Task;