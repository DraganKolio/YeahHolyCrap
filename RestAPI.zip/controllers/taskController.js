// Import the Task model from the taskModel.js file - the DB Schema
const Task = require('../models/taskModel');

// Define controller methods for each route
// Method for retrieving all tasks
exports.getAllTasks = async (req, res) => {
  try {
    const tasks = await Task.find();
    res.status(200).json(tasks);
  } catch (err) {
    res.status(500).json({ error: 'Tasks could not be fetched.' });
  }
}

// Method for retrieving a task by its
/*exports.getTaskById = async (req, res) => {
  try {
    const task = await Task.findById(req.params._id.toString());
    res.status(200).json(task);
  } catch (err) {
    res.status(500).json({ error: 'Task could not be fetched' });
  }
}*/

// Method for creating a task
exports.createTask = async (req, res) => {
  try {
    const newTask = await Task.create(req.body);
    res.status(201).json(newTask);
  } catch (err) {
    res.status(400).json({ error: 'Invalid task parameters' });
  }
};

// Method for updating a task
exports.updateTask = async (req, res) => {
  try {
    const updatedTask = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.status(200).json(updatedTask);
  } catch (err) {
    res.status(404).json({ error: 'Task not found' });
  }
};

// Method for deleting a task
exports.deleteTask = async (req, res) => {
  try {
    await Task.findByIdAndDelete(req.params.id);
    res.status(204).send();
  } catch (err) {
    res.status(404).json({ error: 'Task not found' });
  }
}