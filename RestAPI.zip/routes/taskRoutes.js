// Dependencies
const express = require('express');
const router = express.Router();
const taskController = require('../controllers/taskController');

// Define routes and their corresponding controller methods
router.get('/tasks', taskController.getAllTasks);
router.get('/tasks/:id', async (req, res) => {
  try {
    const taskId = req.params.id;

    const mongoose = require('mongoose');
    const ObjectId = mongoose.types.ObjectId;
    const taskObjectId = new ObjectId(taskId);

    const task = await Task.findById(taskObjectId);

    if (!task) {
      return res.status(404).json({ message: 'Task not found.' });
    }

    const taskWithIdAsString = {
      ...task.toObject(),
      _id: task._id.toString()
    };

    res.json(taskWithIdAsString);
  } catch (err) {
    console.error('Error fetching task: ', err);
    res.status(500).json({ message: 'Internal server error.' });
  }
});
router.post('/tasks', taskController.createTask);
router.put('/tasks/:id', taskController.updateTask);
router.delete('/tasks/:id', taskController.deleteTask);

module.exports = router;