module.exports = {
  DB_URI: 'mongodb://localhost:27017/todo-app',
}